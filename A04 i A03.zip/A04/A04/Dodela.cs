﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A04
{
    public partial class Dodela : Form
    {
        SqlConnection konekcija = new SqlConnection();
        SqlCommand komanda;
        public Dodela()
        {
            InitializeComponent();
            konekcija.ConnectionString = "Data Source=-NEMANJA-\\SQLEXPRESS;Initial Catalog=seoski_turizam;Integrated Security=True";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            konekcija.Open();
            string sql = "select concat(trim(k.ime),' ',trim(k.prezime)) as Ime, count(r.klijentID) as Broj" +
                " from klijent k join rezervacija r on k.klijentid=r.klijentid" +
                " where k.AktivanKlijent = 'DA'" +
                " group by concat(trim(k.ime),' ',trim(k.prezime))" +
                " having count(r.klijentID) > "+ numericUpDown1.Value;
            komanda = new SqlCommand(sql,konekcija);
            SqlDataReader citac = komanda.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(citac);
            dataGridView1.DataSource = dt;
            konekcija.Close();
        }
    }
}
