﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace A04
{

    public partial class Form1 : Form
    {
        SqlConnection konekcija = new SqlConnection();
        SqlCommand komanda;
        public Form1()
        {
            InitializeComponent();
            konekcija.ConnectionString = "Data Source=-NEMANJA-\\SQLEXPRESS;Initial Catalog=seoski_turizam;Integrated Security=True";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PopuniL();
            PopuniC();
        }

        void PopuniL()
        {
            listView1.Items.Clear();
            string sql = "select seloid, trim(naziv), trim(grad) from selo s join grad g on s.gradid=g.gradid";
            konekcija.Open();
            komanda = new SqlCommand(sql, konekcija);
            SqlDataReader citac = komanda.ExecuteReader();
            while (citac.Read())
            {
                ListViewItem red = new ListViewItem();
                red.Text = citac.GetValue(0).ToString();
                for (int i = 1; i < 3; i++)
                {
                    red.SubItems.Add(citac.GetValue(i).ToString());
                }
                listView1.Items.Add(red);
            }
            konekcija.Close();
        }

        void PopuniC()
        {
            konekcija.Open();
            string sql = "select trim(grad) as grad,gradid from grad" +
                " order by grad ASC";
            komanda = new SqlCommand(sql, konekcija);
            SqlDataReader citac = komanda.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(citac);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "grad";
            comboBox1.ValueMember = "gradid";
            konekcija.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Dodela dod = new Dodela();
            dod.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && comboBox1.Text != "")
            {
                konekcija.Open();
                string sql = "update selo set naziv=@naziv,gradid=@gradid" +
                    " where seloid = " + textBox1.Text;
                komanda = new SqlCommand(sql, konekcija);
                komanda.Parameters.AddWithValue("@naziv", textBox2.Text);
                komanda.Parameters.AddWithValue("@gradid", comboBox1.SelectedValue);
                int n = komanda.ExecuteNonQuery();
                if (n > 0)
                {
                    MessageBox.Show("Uspesna izmena!");
                    string s = "log_" + DateTime.Now.ToString("dd.MM.yyyy.")+".txt";
                    string a =  textBox1.Text + " " + textBox2.Text+ " " +comboBox1.Text + Environment.NewLine;
                    File.AppendAllText(s, a);
                    konekcija.Close();
                    PopuniL();
                }
            }
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            listView1.SelectedIndices.Clear();
            if (!int.TryParse(textBox1.Text, out int n))
            {

                textBox1.Text = "";
                textBox2.Text = "";
                comboBox1.Text = "";
            }
            else
            {
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    if (n == Convert.ToInt32(listView1.Items[i].Text))
                    {
                        listView1.Items[i].Selected = true;
                        ListViewItem red = listView1.Items[i];
                        textBox1.Text = red.SubItems[0].Text;
                        textBox2.Text = red.SubItems[1].Text;
                        comboBox1.Text = red.SubItems[2].Text;
                        return;
                    }
                    else
                    {
                        textBox2.Text = "";
                        comboBox1.Text = "";
                    }
                }
            }
            }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                string sql = "create table Usluga(" +
                    " UslugaID int primary key," +
                    " NazivU nchar(20) not null);" +

                    " create table UslugaKucica(" +
                    " UslugaID int not null," +
                    " kucicaid int not null," +
                    " IznosOD money not null," +
                    " IznosDO money not null," +
                    " BrojUsluga int);" +

                    " alter table UslugaKucica" +
                    " add constraint PKK primary key(UslugaID,kucicaID);" +

                    " alter table UslugaKucica" +
                    " add constraint FKK foreign key (UslugaID) references Usluga(UslugaID);" +

                    " alter table UslugaKucica" +
                    " add constraint FKK1 foreign key (kucicaid) references kucica(kucicaid);" +

                    " alter table UslugaKucica" +
                    " add constraint cekic check(IznosOD<IznosDO);";

                konekcija.Open();
                komanda = new SqlCommand(sql, konekcija);
                komanda.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Baza je vec prosirena");
            }
        }
    }
    }