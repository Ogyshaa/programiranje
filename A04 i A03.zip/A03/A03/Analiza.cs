﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A03
{
    public partial class Analiza : Form
    {
        SqlConnection konekcija = new SqlConnection();
        SqlCommand komanda;
        DataTable dt;
        public Analiza()
        {
            InitializeComponent();
            konekcija.ConnectionString = "Data Source=-NEMANJA-\\SQLEXPRESS;Initial Catalog=EvidencijaradnikaA03;Integrated Security=True";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            konekcija.Open();
            string sql = "select year(datum_pocetka) as Godina, count(p.projekat_id) as [Broj projekata]," +
                " count(distinct radnik_id) as [Broj radnika] from Projekat p join Angazman a on" +
                " p.Projekat_ID=a.PRojekat_id" +
                " where datum_pocetka > dateadd(year,-@brojGod,getdate())" +
                " group by year(datum_pocetka)" +
                " order by year(datum_pocetka) ASC";    
            komanda = new SqlCommand(sql,konekcija);
            komanda.Parameters.AddWithValue("@brojGod", numericUpDown1.Value);
            SqlDataReader citac = komanda.ExecuteReader();
            dt = new DataTable();
            dt.Load(citac);
            dataGridView1.DataSource = dt;
            chart1.DataSource = dt;
            chart1.Series[0].XValueMember = "Godina";
            chart1.Series[0].YValueMembers = "Broj radnika";
            chart1.DataBind();
            konekcija.Close();
        }
    }
}
