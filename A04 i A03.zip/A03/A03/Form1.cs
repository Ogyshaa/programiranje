﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace A03
{
    public partial class Form1 : Form
    {

        SqlConnection konekcija = new SqlConnection();
        SqlCommand komanda;
        public Form1()
        {
            InitializeComponent();
            konekcija.ConnectionString = "Data Source=-NEMANJA-\\SQLEXPRESS;Initial Catalog=EvidencijaradnikaA03;Integrated Security=True";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            PopuniL();
        }

        void PopuniL()
        {
            listView1.Items.Clear();
            string sql = "select projekat_id, trim(naziv), trim(format(datum_pocetka,'dd.MM.yyyy.')), budzet, projekat_zavrsen,opis from projekat";
            konekcija.Open();
            komanda = new SqlCommand(sql, konekcija);
            SqlDataReader citac = komanda.ExecuteReader();
            while (citac.Read())
            {
                ListViewItem red = new ListViewItem();
                red.Text = citac.GetValue(0).ToString();
                for(int i = 1;i< 6; i++)
                {
                    red.SubItems.Add(citac.GetValue(i).ToString()); 
                }
                listView1.Items.Add(red);
            }
            konekcija.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count > 0)
            {
                ListViewItem red = listView1.SelectedItems[0];
                textBox1.Text = red.Text;
                textBox2.Text = red.SubItems[1].Text;
                textBox3.Text = red.SubItems[2].Text;
                textBox4.Text = red.SubItems[3].Text;
                checkBox1.Checked = Convert.ToBoolean(red.SubItems[4].Text);
                textBox5.Text = red.SubItems[5].Text;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "delete from projekat where projekat_id = " + textBox1.Text + " and projekat_zavrsen = 1 and" +
                " datum_pocetka < dateadd(year,-1,getdate())";
            konekcija.Open();
            komanda = new SqlCommand(sql,konekcija);
            int n = komanda.ExecuteNonQuery();
            if (n > 0) 
            {
                MessageBox.Show("Uspesno obrisan projekat!");
                string s = "log_" + DateTime.Now.ToString("dd.MM.yyyy") + ".txt";
                string[] a = { textBox1.Text+ " " + textBox2.Text};
                File.AppendAllLines(s, a);
                konekcija.Close();
                PopuniL();
            }
            else
            {
                MessageBox.Show("Projekat moze da se izbrise samo ako je stariji od 5 godina i zavrsen je!");
                konekcija.Close();
                PopuniL();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Analiza ana = new Analiza();
            ana.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            konekcija.Open();
            string sql = "create table Podizvodjac(" +
                " PodizvodjacID int primary key," +
                " Ime nchar(20) not null);" +
                
                " create table AngazmanP(" +
                " PodizvodjacID int not null," +
                " ProjekatID int not null," +
                " DatumPocetka date not null default getdate()," +
                " DatumZavrsetka date not null default datefromparts(year(getdate(),12,31))";

        }
    }
}
