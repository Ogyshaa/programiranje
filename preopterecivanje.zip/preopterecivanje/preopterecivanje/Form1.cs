﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace preopterecivanje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private bool isti = false;
        int a, b, a1, b1;
        private void btn_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txta.Text);
            b = Convert.ToInt32(txtb.Text);

            a1 = Convert.ToInt32(txta1.Text);
            b1 = Convert.ToInt32(txtb1.Text);

            Pravougaonik pr = new Pravougaonik(a, b);
            Pravougaonik pr1 = new Pravougaonik(a1, b1);

            isti = pr.Equals(pr1);
            Invalidate();

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;

            Pen pen = new Pen(Color.Black);

            Pravougaonik pr = new Pravougaonik(a, b);
            Pravougaonik pr1 = new Pravougaonik(a1, b1);

            if (isti)
            {
                g.DrawRectangle(pen, 200, 200, pr.A, pr.B);
            }
            else
            {
                g.DrawRectangle(pen, 200, 200, pr.A, pr.B);
                g.DrawRectangle(pen, 200 + pr.A + 10, 200, pr1.A, pr1.B);
            }
        }
    }
}