﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Web;

namespace Distribucija_lekova
{
    public partial class FromAnaliza : Form
    {
        public FromAnaliza()
        {
            InitializeComponent();
        }
        SqlConnection konekcija = new SqlConnection();
        SqlCommand komanda;
        DataTable dt = new DataTable();
        private void FromAnaliza_Load(object sender, EventArgs e)
        {
            this.Text = "Statistika";
            string str = "Data Source=-NEMANJA-\\SQLEXPRESS;Initial Catalog=distribucija_lekova;Integrated Security=True;";
            konekcija.ConnectionString = str;
            Ucitaj();
        }
        private void Ucitaj()
        {
            konekcija.Open();
            string sql = "select proizvodjacID, naziv from proizvodjac";
            komanda = new SqlCommand(sql, konekcija);
            SqlDataReader citac = komanda.ExecuteReader();
            dt.Load(citac);
            konekcija.Close();
            komanda.Dispose();

            checkedListBox1.DataSource = dt;
            checkedListBox1.DisplayMember = "naziv";
            checkedListBox1.ValueMember = "proizvodjacID";
        }

         private void button1_Click(object sender, EventArgs e)
        {
            chart1.Series.Clear();

            var series = chart1.Series.Add("Lekovi");
            series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;

            foreach (DataRowView item in checkedListBox1.CheckedItems)
            {
                int pid = (int)item["proizvodjacID"];
                string naziv = item["naziv"].ToString();

                string sql =
                    "SELECT COUNT(*) FROM lek WHERE proizvodjacID = @pid";

                SqlCommand cmd = new SqlCommand(sql, konekcija);
                cmd.Parameters.AddWithValue("@pid", pid);

                konekcija.Open();
                int broj = (int)cmd.ExecuteScalar();
                konekcija.Close();

                if (broj > 0)
                    series.Points.AddXY(naziv, broj);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}