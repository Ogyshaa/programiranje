﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Distribucija_lekova
{
    public partial class Form1 : Form
    {
        SqlConnection konekcija = new SqlConnection();
        DataTable tabela;
        public Form1()
        {
            InitializeComponent();
            string str = @"Data Source=-NEMANJA-\SQLEXPRESS;Initial Catalog=distribucija_lekova;Integrated Security = true;";
            konekcija.ConnectionString = str;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Ucitaj();
            dataGridView1.DataSource = tabela;
            textBox1.Text = dataGridView1.Rows[0].Cells[2].Value.ToString();
            textBox2.Text = dataGridView1.Rows[0].Cells[4].Value.ToString();
        }
        public void Ucitaj()
        {
            string sql = "select lekID as [Sifra leka], l.proizvodjacID as [Sifra proizbodjaca]," +
                         " naziv_leka as [Naziv leka], nezasticeno_ime as [Nezasticeno ime], p.naziv as Naziv" +
                         " from lek l join proizvodjac p on l.proizvodjacID = p.proizvodjacID" +
                         " group by lekID, l.proizvodjacID, naziv_leka, nezasticeno_ime, p.naziv" +
                         " order by naziv_leka;";
            SqlCommand komanda = new SqlCommand(sql, konekcija);
            try
            {
                tabela = new DataTable();
                konekcija.Open();
                SqlDataReader citac = komanda.ExecuteReader();
                tabela.Load(citac);
                konekcija.Close();
                komanda.Dispose();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            }
        }

        private void Brisanje_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DialogResult rez;
                rez = MessageBox.Show("Da li ste sigurni da zelite da brisete?", "Potvrda", MessageBoxButtons.YesNo);
                if (rez == DialogResult.Yes)
                {
                    int lekid = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    string str = " delete from lek where lekID =" + lekid;
                    konekcija.Open();
                    SqlCommand komanda = new SqlCommand(str,konekcija);
                    komanda.ExecuteNonQuery();
                    konekcija.Close();
                    komanda.Dispose();
                }
                Form1_Load(this, e);
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            form2 form2 = new form2();
            form2.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            FromAnaliza from = new FromAnaliza();
            from.ShowDialog();
        }
    }
}