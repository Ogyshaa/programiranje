﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
namespace Utility1
{
    public static class MetodeF
    {
        public static void CitajTxt(string path, List<string> redovi,int i)
        {
            StreamReader sr = new StreamReader(path);
            while (!sr.EndOfStream)
            {
                redovi.Add(sr.ReadLine());
            }

        }
        public static void PuniLB(ListBox lb, List<string> stavke)
        {
            foreach(string red in stavke)
            {
                lb.Items.Add(red);
            }
        }
    }
}
