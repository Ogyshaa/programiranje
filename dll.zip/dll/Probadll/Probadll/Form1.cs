﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Utility1;
namespace Probadll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPrikazi_Click(object sender, EventArgs e)
        {
            List<string> stavke = new List<string>();
            if(ofd.ShowDialog() == DialogResult.OK)
            {
               
                MetodeF.CitajTxt(ofd.FileName,stavke,10);
                MetodeF.PuniLB(lb1, stavke);

            }
        }
    }
}
