﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<int> lista,lista1;
        DynArr dyn;
        private void Form1_Load(object sender, EventArgs e)
        {
            lista = new List<int>();
            lista1 = new List<int>();
            dyn = new DynArr();
            
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            int num = 0;
            if(int.TryParse(txtBox1.Text, out num))
            {
                lista.Add(num);
                dyn.Show(lista, lBox1);
                
            }
            else MessageBox.Show("Input value is not valid!\n"+ "String and char are not SUPPORTED!!! ");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dyn.Reversed(lista, lista1);
            dyn.Show(lista1, listBox1);

            
        }

        private void btnFIND_Click(object sender, EventArgs e)
        {
            if (lista.Count > 0)
            {
                dyn.Max = lista[0];
                for (int i = 1; i < lista.Count; i++)
                {
                    dyn.Max = dyn.Highest(dyn.Max, lista[i]);
                }
                lb1.Text = dyn.Max.ToString();
            }
            else MessageBox.Show("Dynamic array is empty!");
        }
    }
}
