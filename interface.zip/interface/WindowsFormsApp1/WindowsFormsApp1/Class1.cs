﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp1
{
    interface I_list
    {
        
        int Max
        {
            get;
            set;
        }

        int Highest(int a, int b);

        void Show(List<int> l, ListBox listBox);
    }
    class DynArr : I_list
    {
        public void Reversed (List<int> l1, List<int> l2)
        {
            l2.Clear();
            foreach (int i in l1)
                l2.Add(i);
            l2.Reverse();

          
        }

        private int max = 0;
        public int Max
        {
            get { return max; }
            set { max = value; }
        }
        public int Highest(int a, int b)
        {
            if (a >= b)
            {
                return a;
            }
            else return b;
        }
        public void Show(List<int> l, ListBox listBox)
        {
            listBox.Items.Clear();
            foreach (int i in l)
                listBox.Items.Add(i);
        }

    }

}
