﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace listanje_txt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StreamReader sr = null;
            string fname;
            string row = " ";
            ofdList.InitialDirectory = @"D:\Ognjen Radojkovic";
            ofdList.Filter = "Text files|*.txt|Document|*.doc|All Files|*.*";
            ofdList.FilterIndex = 1;
            ofdList.Multiselect = false;
            if(ofdList.ShowDialog()== DialogResult.OK)
            {
                fname = ofdList.FileName;
                sr = new StreamReader(fname);

                while ((row = sr.ReadLine()) != null)
                {
                    row = sr.ReadLine();
                    libDisplay.Items.Add(row);
                }
                sr.Close();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string fname = "";
            StreamWriter sw = null;
            if (sfdList.ShowDialog() == DialogResult.OK)
            {
                fname = sfdList.FileName;
                sw = new StreamWriter(fname);
                for(int i = 0; i < libDisplay.Items.Count;i++)
                {
                    sw.WriteLine(libDisplay.Items[i].ToString());
                }
                sw.Flush();
                sw.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            libDisplay.Items.Add(txtbInput.Text);
        }
    }
}
